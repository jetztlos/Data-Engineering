{{ dbt_date.get_date_dimension("YYYY-MM-DD", "YYYY-MM-DD") }}
